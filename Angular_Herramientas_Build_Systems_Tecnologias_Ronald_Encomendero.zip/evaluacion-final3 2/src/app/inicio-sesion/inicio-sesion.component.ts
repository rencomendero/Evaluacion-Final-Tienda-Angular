import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

import { AngularFireDatabase } from 'angularfire2/database';
//import * as firebase from 'firebase';
import "firebase/auth";
import firebase from "firebase/app";

import { Router } from '@angular/router';


@Component({
  selector: 'app-inicio-sesion',
  templateUrl: './inicio-sesion.component.html',
  styleUrls: ['./inicio-sesion.component.css']
})
export class InicioSesionComponent implements OnInit {

  //firebase: firebase;

  formulario : FormGroup;
  usuario: string;

  constructor(public db: AngularFireDatabase, private router : Router) {

    var database = firebase.database();
    var referencia = database.ref("usuarios");
    var productos = {};

//REALTIME DATABASE//
    // referencia.on('child_added', function(datos, prevChildKey){
    //   productos = datos.val();
    //   if (productos.email == 'Ronald') {
    //   //  console.log("SI ESTAS");
    //   } else {
    //   //  console.log("NO ESTAS");
    //   }
    // });

//FIRESTORE//
    // var firestoredatabase = firebase.firestore();
    // firestoredatabase.collection('Usuarios').doc('admin@hotmail.com').get().then(doc => {
    // //  console.log(doc.data().apellido);
    // });

//AUTH//
    firebase.auth().onAuthStateChanged(function(user){
      if (user) {
        //console.log('Usuario registrado: ' + user.email);
        //firebase.auth().signOut();
      } else {
        //console.log('Usuario no registrado');
      }
    })
}

  ngOnInit() {
    this.formulario = new FormGroup(
      {
        email : new FormControl(),
        password: new FormControl()
      }
    )
  }

  enviarform(){
    // var prod = new Object();
    // var datab = firebase.database().ref("usuarios");
    // datab.on('child_added', function(snapshot){
    //   prod.email = snapshot.val().email;
    //   prod.contrasena = snapshot.val().contrasena;
    //   //console.log ((prod.email) + (prod.contrasena));
    // })

    //console.log(this.formulario.value.email);

     firebase.auth().signInWithEmailAndPassword(this.formulario.value.email, this.formulario.value.password).then((user)=>{
       this.router.navigate(['vistaPrincipal']);
     })
     .catch(function(error){
       alert('Usuario NO REGISTRADO');
     });
  }
}
