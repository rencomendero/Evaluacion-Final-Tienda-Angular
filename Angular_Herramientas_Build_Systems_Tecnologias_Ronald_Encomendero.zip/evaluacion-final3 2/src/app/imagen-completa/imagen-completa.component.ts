import { Component, OnInit } from '@angular/core';

import { ServicioFirestoreService } from "../services/servicio-firestore.service";
import { Router } from '@angular/router';

import * as firebase from 'firebase/app';

@Component({
  selector: 'app-imagen-completa',
  templateUrl: './imagen-completa.component.html',
  styleUrls: ['./imagen-completa.component.css']
})
export class ImagenCompletaComponent implements OnInit {

  products = {
    url: "",
    nombre:"",
    precio:"",
    stock:""
  };
  cantidadCarrito;
  firebase;
  constructor(private router : Router, private servicio: ServicioFirestoreService) { }

  ngOnInit() {
    this.products = this.servicio.getData();
    var firestoredatabase = firebase.firestore();
    firestoredatabase.collection('DatosEvaluacion').doc('datos').get().then(datos => {
      this.cantidadCarrito = datos.data().cantidad;
    });

    if(this.products.nombre) {
      //console.log(this.servicio.getData().nombre);
      //console.log(this.servicio.getData().stock);
    } else {
      this.router.navigate(['vistaPrincipal']);
    }
  }
}
