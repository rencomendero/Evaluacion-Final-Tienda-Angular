import { BusquedaPipe } from './busqueda.pipe';

describe('BusquedaPipe', () => {
  it('create an instance', () => {
    const pipe = new BusquedaPipe();
    expect(pipe).toBeTruthy();
  });
});
