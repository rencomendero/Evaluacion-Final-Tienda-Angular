import { TestBed } from '@angular/core/testing';

import { ServicioFirestoreService } from './servicio-firestore.service';

describe('ServicioFirestoreService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ServicioFirestoreService = TestBed.get(ServicioFirestoreService);
    expect(service).toBeTruthy();
  });
});
