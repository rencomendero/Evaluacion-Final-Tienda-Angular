import { Injectable } from '@angular/core';

import { FormControl, FormGroup } from "@angular/forms";

import { AngularFirestore } from "@angular/fire/firestore";

@Injectable({
  providedIn: 'root'
})
export class ServicioFirestoreService {

  constructor(private firestore: AngularFirestore) { }

  getProducts() {
    return this.firestore.collection("ProductosEvaluacion").snapshotChanges();
  }

  addCart(data, producto){
    return new Promise<any>((resolve, reject) => {
      this.firestore.collection("DatosEvaluacion").doc("datos").update(data).then(res => {}, err => reject(err));
      this.firestore.collection("DatosEvaluacion").doc("carrito").collection("productos").add(producto).then(res => {}, err => reject(err));
    });
  }

  getCarrito() {
    return this.firestore.collection("DatosEvaluacion").doc("carrito").collection("productos").snapshotChanges();
  }

  sharingData: myData={name:"vacio"};
  saveData(str){
    this.sharingData.name=str;
  }
  getData(){
    return this.sharingData.name;
  }
}

export interface myData {
  name;
}
