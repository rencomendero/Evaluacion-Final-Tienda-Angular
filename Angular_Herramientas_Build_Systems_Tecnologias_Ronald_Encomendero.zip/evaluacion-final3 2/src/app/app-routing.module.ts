import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InicioSesionComponent } from './inicio-sesion/inicio-sesion.component';
import { VistaPrincipalComponent } from './vista-principal/vista-principal.component';
import { ImagenCompletaComponent } from './imagen-completa/imagen-completa.component';
import { CarritoComponent } from './carrito/carrito.component';

const routes: Routes = [
  { path: '', component: InicioSesionComponent },
  { path: 'vistaPrincipal', component: VistaPrincipalComponent },
  { path: 'inicio', component: InicioSesionComponent },
  { path: 'imagenCompleta', component: ImagenCompletaComponent },
  { path: 'carrito', component: CarritoComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
