import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InicioSesionComponent } from './inicio-sesion/inicio-sesion.component';

import { ReactiveFormsModule } from '@angular/forms';

import { AngularFireModule } from "@angular/fire";
import { AngularFirestoreModule } from "@angular/fire/firestore";
import { AngularFireDatabaseModule } from "@angular/fire/database";
import { VistaPrincipalComponent } from './vista-principal/vista-principal.component';
import { BarraSuperiorComponent } from './barra-superior/barra-superior.component';

import { ServicioFirestoreService } from "./services/servicio-firestore.service";
import { BusquedaPipe } from './busqueda.pipe';
import { ImagenCompletaComponent } from './imagen-completa/imagen-completa.component';
import { CarritoComponent } from './carrito/carrito.component';

const firebaseConfig = {
  apiKey: "AIzaSyBsTg-KklvBFTRCDWqaqtrxvcPXr1w_BPY",
  authDomain: "al-mercado-app.firebaseapp.com",
  databaseURL: "https://al-mercado-app.firebaseio.com",
  projectId: "al-mercado-app",
  storageBucket: "al-mercado-app.appspot.com",
  messagingSenderId: "680027008679",
  appId: "1:680027008679:web:b4c994b4cc377db3"
};

@NgModule({
  declarations: [
    AppComponent,
    InicioSesionComponent,
    VistaPrincipalComponent,
    BarraSuperiorComponent,
    BusquedaPipe,
    ImagenCompletaComponent,
    CarritoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    AngularFirestoreModule
  ],
  providers: [ServicioFirestoreService],
  bootstrap: [AppComponent]
})
export class AppModule { }
