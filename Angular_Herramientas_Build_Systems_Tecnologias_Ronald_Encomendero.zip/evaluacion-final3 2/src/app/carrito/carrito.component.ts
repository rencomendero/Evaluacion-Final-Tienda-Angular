import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { ServicioFirestoreService } from "../services/servicio-firestore.service";

import firebase from "firebase/app";

import { AngularFirestore } from "@angular/fire/firestore";

@Component({
  selector: 'app-carrito',
  templateUrl: './carrito.component.html',
  styleUrls: ['./carrito.component.css']
})
export class CarritoComponent implements OnInit {

  productos;
  cantidadCarrito;
  firebase;
  subtotal;
  total;
  lenghtProductos=0;
  ids = [];
  cantidadVendida = [];

  constructor(private router : Router, private servicio: ServicioFirestoreService, private firestore: AngularFirestore) { }

  ngOnInit() {
    this.getProducts();
    var firestoredatabase = firebase.firestore();
    firestoredatabase.collection('DatosEvaluacion').doc('datos').get().then(datos => {
      this.cantidadCarrito = datos.data().cantidad;
      if (this.cantidadCarrito>0){
        this.totalizar();
      } else {
        alert('Carrito de Compras vacío')
        this.router.navigate(['vistaPrincipal']);
      }
    });
  }

  getProducts(){
    this.servicio.getCarrito().subscribe(res => {
      this.productos = res
    });
  }

  totalizar(){
    this.firestore.collection("ProductosEvaluacion").valueChanges().subscribe(queriedItems => {
      this.lenghtProductos=0;
      for (var key in queriedItems){
        if (queriedItems.hasOwnProperty(key)){
          ++this.lenghtProductos;
        }
      }});

    this.firestore.collection("DatosEvaluacion").doc("carrito").collection("productos").valueChanges().subscribe(queriedItems => {
      this.subtotal=0;
      this. total=0;

      for (let i=0; i<this.cantidadCarrito; i++){
        this.ids[i] = queriedItems[i].id;
        this.cantidadVendida[i] = queriedItems[i].cantidadRequerida;
        this.subtotal = (queriedItems[i].precio)*(queriedItems[i].cantidadRequerida);
        this.total = this.total + this.subtotal;
      }
    });
  }

  pagar(){
    for (let i=0; i<this.cantidadCarrito; i++){
      var firestoredatabase = firebase.firestore();
      firestoredatabase.collection("ProductosEvaluacion").doc(this.ids[i]).get().then(recontra =>{
        this.firestore.collection("ProductosEvaluacion").doc(this.ids[i]).update({stock: ((recontra.data().stock) - (this.cantidadVendida[i]))});
        console.log(this.productos[i].payload.doc.id);
        this.firestore.collection("DatosEvaluacion").doc("carrito").collection("productos").doc(this.productos[i].payload.doc.id).delete();
      });
    }
    this.firestore.collection("DatosEvaluacion").doc("datos").update({cantidad: 0});
    alert('Compra realizada, se enviarán los productos pronto.')
    this.router.navigate(['vistaPrincipal']);
  }
}
