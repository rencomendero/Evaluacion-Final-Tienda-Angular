import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ServicioFirestoreService } from "../services/servicio-firestore.service";

import firebase from "firebase/app";

import { AngularFirestore } from "@angular/fire/firestore";

@Component({
  selector: 'app-vista-principal',
  templateUrl: './vista-principal.component.html',
  styleUrls: ['./vista-principal.component.css']
})
export class VistaPrincipalComponent implements OnInit {

  productos;
  products = {
    url:"",
    nombre:"",
    precio:"",
    stock:""
  };
  cantidadCarrito;
  firebase;
  data;
  idCart;

  constructor(private router : Router, private servicio: ServicioFirestoreService, private firestore: AngularFirestore) { }


  ngOnInit() {
    this.getProducts();
    var firestoredatabase = firebase.firestore();
    firestoredatabase.collection('DatosEvaluacion').doc('datos').get().then(datos => {
      this.cantidadCarrito = datos.data().cantidad;
    });
  }

  //getProducts = () => this.servicio.getProducts().subscribe(res => (this.productos = res));
  getProducts(){
    this.servicio.getProducts().subscribe(res => (this.productos = res));
  }

  verImagenCompleta(productoURL, productoNombre, productoPrecio, productoStock){
    this.products.url = productoURL;
    this.products.nombre = productoNombre;
    this.products.precio = productoPrecio;
    this.products.stock = productoStock;
    this.servicio.saveData(this.products);
    this.router.navigate(['imagenCompleta']);
  }

  agregarCarrito(id,url, nombre, precio, stock, valorCantidad){
    this.cantidadCarrito++;
    this.data = {
      cantidad: this.cantidadCarrito
    };

    this.idCart = {
      id: id,
      url: url,
      nombre: nombre,
      precio: precio,
      stock: stock,
      cantidadRequerida: valorCantidad
    }
    this.servicio.addCart(this.data, this.idCart);
    alert('Se agregó producto al carrito');
  }
}
